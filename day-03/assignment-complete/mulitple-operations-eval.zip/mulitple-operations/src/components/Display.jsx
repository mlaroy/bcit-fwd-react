function Display({ digits }) {
    return (
        <div className="display">
            {digits}
        </div>
    );
}

export default Display
