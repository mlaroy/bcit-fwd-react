function Header() {
    return (
        <header>
            <h1>React Calculator</h1>
        </header>
    );
}

export default Header
