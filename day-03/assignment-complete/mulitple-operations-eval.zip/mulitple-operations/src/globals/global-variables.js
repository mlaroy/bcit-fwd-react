// Global Variables
export const maximumDisplayDigits = 15;
export const maximumInteger = 999999999999999;