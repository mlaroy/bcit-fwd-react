import { useState, useEffect } from 'react';
import Nav from './Nav';

const Header = () => (
    <header>
        <h1>React Tabs</h1>
    </header>
);

export default Header;
