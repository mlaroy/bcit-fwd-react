const Main = () => (
    <main>
        <section className="product-info">
            <h2>Tabs</h2>
            <p>Insert tabs here...</p>
        </section>
    </main>
);

export default Main;