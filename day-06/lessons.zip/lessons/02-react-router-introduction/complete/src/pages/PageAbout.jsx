// Page - About

const PageAbout = () => {

	return (
		<section>
			<h2>About Page</h2>
			<p>Saepe vitae deserunt cupiditate vel reiciendis adipisci quasi. At, dolore qui, saepe similique id repellat ipsam sapiente repellendus commodi deleniti natus itaque hic temporibus nam nobis tempora enim suscipit quas!</p>
		</section>
	);
	
};

export default PageAbout;