import Approuter from './routers/Approuter'

function App() {

  return (
    <>
        <Approuter />
    </>
  )
}

export default App
