// Page - Contact

const PageContact = () => {

	return (
    	<section>
			<h2>Contact Me</h2>
			<p>Email me at: <a href="mailTo:info@mwhyte.ca">hello@mikelaroy.ca</a></p>
		</section>
	);

};

export default PageContact;
